"use client";
import PageBanner from "@/components/PageBanner";
import Reveal from "@/components/Reveal";
import Link from "next/link";

const NOTES = [
  "Ακολουθούμε τα διεθνή πρότυπα των barber events. Για αυτό δεν θα έχουμε καθρέπτες αυξάνοντας το βαθμό δυσκολίας.",
  "Χρειάζονται 2 μοντέλα για την συμμετοχή σας στον διαγωνισμό.",
  "Τα μοντέλα του διαγωνισμού που δεν έχουν καμία σχέση με τον κλάδο η είσοδος τους είναι δωρεάν και θα πρέπει μετά την λήξη του διαγωνισμού να αποχωρήσουν από τις αίθουσες που διαδραματίζεται το φεστιβάλ.",
  "Εάν το επιθυμείτε μπορείτε να κλείσετε ραντεβού με τους φωτογράφους του φεστιβάλ για την λήψη φωτογραφιών ή δημιουργία βίντεο μόνο για εσάς σε προνομιακή τιμή.",
  "Η διοργάνωση δεν φέρει καμία ευθύνη για τυχόν απώλειες ή ζημιές των εργαλείων σας.",
  "Υποχρεωτική η βεβαίωση σπουδών από την γραμματεία της σχολής σας.",
  "Δεν επιτρέπονται τα διακριτικά σχολών κατά την διάρκεια του διαγωνισμού.",
  "Η διοργάνωση μπορεί να αναδημοσιεύσει φωτογραφίες δικές σας και των μοντέλων για διαφημιστικούς λόγους.",
];

export default function StudentCompetitionPage() {
  return (
    <>
      <PageBanner title="ΜΑΘΗΤΙΚΟΣ ΔΙΑΓΩΝΙΣΜΟΣ" image="https://static.wixstatic.com/media/335ee3_9c6d7b8f7e694e40b10bda0de7eee0f0~mv2.jpg/v1/fill/w_1920,h_600,al_c,q_80,enc_avif,quality_auto/LSD_4282.jpg" />
      <section style={{ padding: "80px 24px", maxWidth: 900, margin: "0 auto" }}>

        {/* Top crowd image */}
        <Reveal>
          <div style={{ borderRadius: 16, overflow: "hidden", border: "1px solid rgba(200,168,78,0.2)", marginBottom: 40 }}>
            <img src="/student-crowd.png" alt="Student Competition" style={{ width: "100%", height: "auto", display: "block" }} />
          </div>
        </Reveal>

        {/* Intro */}
        <Reveal delay={100}>
          <div style={{ background: "var(--color-charcoal)", borderRadius: 16, padding: "40px 32px", border: "1px solid rgba(200,168,78,0.2)", marginBottom: 30 }}>
            <h2 className="gold-text" style={{ fontSize: "1.5rem", marginBottom: 24, textAlign: "center" }}>ΜΑΘΗΤΙΚΟΣ ΔΙΑΓΩΝΙΣΜΟΣ</h2>
            <p style={{ color: "#ccc", lineHeight: 1.9, marginBottom: 16 }}>
              Στα πλαίσια του 8ου Greek Barber Festival θα διοργανωθεί μαθητικός διαγωνισμός.
            </p>
            <p style={{ color: "#ccc", lineHeight: 1.9, marginBottom: 16 }}>
              Στον μαθητικό διαγωνισμό μπορούν να συμμετέχουν μαθητές σχολών κομμωτικής από δημόσιες, ιδιωτικές, ΕΠΑΛ και ΙΕΚ σχολές.
            </p>
            <p style={{ color: "#ccc", lineHeight: 1.9, marginBottom: 16 }}>
              Τα βραβεία που θα δοθούν, θα επιβραβεύουν τις ικανότητες και την επίδοση των διαγωνιζόμενων μαθητών, οι οποίοι θα κριθούν με τα αυστηρότερα κριτήρια από εκείνους που κατέκτησαν μια από τις τρείς κορυφαίες θέσεις (Best Barber of the Year) στους προηγούμενους 7 διαγωνισμούς του φεστιβάλ. Τα διαγωνιστικά θέματα είναι 2: <strong style={{ color: "var(--color-gold)" }}>&quot;Freestyle Haircut&quot;</strong> &amp; <strong style={{ color: "var(--color-gold)" }}>&quot;Fast &amp; Cleanest Mid Fade&quot;</strong>.
            </p>
            <p style={{ color: "#ccc", lineHeight: 1.9, marginBottom: 20 }}>
              Είναι υποχρεωτικό να δηλώσετε συμμετοχή και στα 2 διαγωνιστικά θέματα.
            </p>
            <div style={{ textAlign: "center", padding: "16px 24px", background: "rgba(200,168,78,0.1)", borderRadius: 10, display: "inline-block", width: "100%" }}>
              <span style={{ fontSize: "2rem", fontFamily: "var(--font-display)", color: "var(--color-gold)" }}>€60</span>
              <p style={{ color: "#aaa", fontSize: "0.85rem", margin: 0 }}>(στην τιμή συμπεριλαμβάνεται και η είσοδος στο φεστιβάλ)</p>
            </div>
          </div>
        </Reveal>

        {/* Cards */}
        <Reveal delay={150}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 24, marginBottom: 30 }}>
            <Link href="/competition/fastestlowfade" className="card-hover" style={{ display: "block", textDecoration: "none", borderRadius: 16, overflow: "hidden", border: "1px solid rgba(200,168,78,0.15)", background: "var(--color-charcoal)" }}>
              <div className="img-zoom" style={{ height: 320 }}>
                <img src="/student-midfade.png" alt="Fast & Cleanest Mid Fade" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: "20px 24px" }}>
                <h3 style={{ color: "var(--color-gold)", fontSize: "1.1rem", marginBottom: 4 }}>Fast &amp; Cleanest Mid Fade</h3>
                <p style={{ color: "#999", fontSize: "0.85rem", marginBottom: 8 }}>Χρόνος: 15 λεπτά</p>
                <p style={{ color: "#bbb", fontSize: "0.85rem", lineHeight: 1.6 }}>Αυτό το θέμα αφορά τον πιο γρήγορο και τον πιο καλό τεχνίτη.</p>
                <span style={{ display: "inline-block", marginTop: 12, color: "var(--color-gold)", fontSize: "0.8rem", fontFamily: "var(--font-display)", borderBottom: "1px solid var(--color-gold)" }}>Περισσότερα →</span>
              </div>
            </Link>
            <Link href="/competition/freestyletotallook" className="card-hover" style={{ display: "block", textDecoration: "none", borderRadius: 16, overflow: "hidden", border: "1px solid rgba(200,168,78,0.15)", background: "var(--color-charcoal)" }}>
              <div className="img-zoom" style={{ height: 320 }}>
                <img src="/student-freestyle.png" alt="Freestyle Haircut" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: "20px 24px" }}>
                <h3 style={{ color: "var(--color-gold)", fontSize: "1.1rem", marginBottom: 4 }}>Freestyle Haircut</h3>
                <p style={{ color: "#999", fontSize: "0.85rem", marginBottom: 8 }}>Χρόνος: 60 λεπτά</p>
                <p style={{ color: "#bbb", fontSize: "0.85rem", lineHeight: 1.6 }}>Θα διαγωνιστείς σε ελεύθερο θέμα χρησιμοποιώντας την φαντασία σου.</p>
                <span style={{ display: "inline-block", marginTop: 12, color: "var(--color-gold)", fontSize: "0.8rem", fontFamily: "var(--font-display)", borderBottom: "1px solid var(--color-gold)" }}>Περισσότερα →</span>
              </div>
            </Link>
          </div>
        </Reveal>

        {/* Notes */}
        <Reveal delay={200}>
          <div style={{ background: "var(--color-charcoal)", borderRadius: 16, padding: "40px 32px", border: "1px solid rgba(200,168,78,0.2)", marginBottom: 30 }}>
            <h3 className="gold-text" style={{ fontSize: "1.2rem", marginBottom: 20 }}>Σημαντικές Σημειώσεις</h3>
            <ol style={{ paddingLeft: 20 }}>
              {NOTES.map((note, i) => (
                <li key={i} style={{ color: "#ccc", fontSize: "0.9rem", lineHeight: 1.8, marginBottom: 10 }}>{note}</li>
              ))}
            </ol>
            <p style={{ color: "#aaa", marginTop: 20, fontSize: "0.9rem" }}>
              Για περισσότερες πληροφορίες επικοινωνήστε στα τηλέφωνα{" "}
              <strong style={{ color: "#ccc" }}>27440-66437</strong> &amp; <strong style={{ color: "#ccc" }}>6936524834</strong> — Μάρρας Πανάγος
            </p>
          </div>
        </Reveal>

        {/* Form */}
        <Reveal delay={300}>
          <div style={{ background: "var(--color-charcoal)", borderRadius: 16, padding: "40px 32px", border: "1px solid rgba(200,168,78,0.2)" }}>
            <h2 className="gold-text" style={{ fontSize: "1.5rem", marginBottom: 30, textAlign: "center" }}>ΔΗΛΩΣΗ ΣΥΜΜΕΤΟΧΗΣ</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 16 }}>
              <input className="form-input" placeholder="Όνομα" />
              <input className="form-input" placeholder="Επίθετο" />
              <input className="form-input" type="email" placeholder="Email" />
              <input className="form-input" placeholder="Τηλέφωνο Επικοινωνίας" />
              <input className="form-input" placeholder="Όνομα Σχολής" style={{ gridColumn: "1 / -1" }} />
            </div>
            <div style={{ marginTop: 16, display: "flex", alignItems: "flex-start", gap: 8 }}>
              <input type="checkbox" id="student-terms" style={{ marginTop: 4, accentColor: "var(--color-gold)" }} />
              <label htmlFor="student-terms" style={{ color: "#999", fontSize: "0.85rem" }}>Αποδέχομαι τους κανονισμούς και δηλώνω συμμετοχή και στα 2 διαγωνιστικά θέματα</label>
            </div>
            <div style={{ textAlign: "center", marginTop: 24 }}>
              <button className="btn-gold">ΕΓΓΡΑΦΗ</button>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
