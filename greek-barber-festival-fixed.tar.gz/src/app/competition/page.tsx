import Link from "next/link";
import PageBanner from "@/components/PageBanner";
import Reveal from "@/components/Reveal";

const CATEGORIES = [
  { title: "Old School Haircut", image: "/comp-oldschool.png", href: "/competition/oldschoolhaircut", time: "60 λεπτά", desc: "Θα διαγωνιστείς σε old school κούρεμα της επιλογής σου." },
  { title: "Modern Barbering", image: "/comp-modern.png", href: "/competition/modernbarbering", time: "60 λεπτά", desc: "Θα διαγωνιστείς σε ένα modern haircut της επιλογής σου." },
  { title: "Fastest Low Fade", image: "/comp-fastest.png", href: "/competition/fastestlowfade", time: "12 λεπτά", desc: "Αυτό το θέμα αφορά τον πιο γρήγορο και τον πιο καλό τεχνίτη." },
  { title: "Freestyle Total Look", image: "/comp-freestyle.png", href: "/competition/freestyletotallook", time: "60 λεπτά", desc: "Θα διαγωνιστείς σε ελεύθερο θέμα χρησιμοποιώντας την φαντασία σου." },
];

const NOTES = [
  "Ακολουθούμε τα διεθνή πρότυπα των barber events. Για αυτό δεν θα έχουμε καθρέπτες αυξάνοντας το βαθμό δυσκολίας.",
  "Τα μοντέλα του επαγγελματικού διαγωνισμού (1+2 διαγωνιστικά θέματα) που είναι επαγγελματίες υπάλληλοι, απόφοιτοι σχολών και σπουδαστές θα πρέπει να πληρώσουν το αντίστοιχο αντίτιμο της γενικής εισόδου.",
  "Τα μοντέλα του διαγωνισμού που δεν έχουν καμία σχέση με τον κλάδο η είσοδος τους είναι δωρεάν και θα πρέπει μετά την λήξη του διαγωνισμού να αποχωρήσουν από τις αίθουσες που διαδραματίζεται το φεστιβάλ.",
  "Δεν επιτρέπονται συνοδοί. (Α' βαθμού συγγένεια 20.00 € συμμετοχή)",
  "Εάν το επιθυμείτε μπορείτε να κλείσετε ραντεβού με τους φωτογράφους του φεστιβάλ για την λήψη φωτογραφιών ή δημιουργία βίντεο μόνο για εσάς σε προνομιακή τιμή.",
  "Η διοργάνωση δεν φέρει καμία ευθύνη για τυχόν απώλειες ή ζημιές των εργαλείων σας.",
  "Η διοργάνωση μπορεί να αναδημοσιεύσει φωτογραφίες δικές σας και των μοντέλων για διαφημιστικούς λόγους.",
  "Η διοργάνωση έχει το δικαίωμα να αλλάξει ή μετατρέψει οποιοδήποτε στοιχείο του διαγωνισμού χωρίς προειδοποίηση.",
];

export default function CompetitionPage() {
  return (
    <>
      <PageBanner title="ΔΙΑΓΩΝΙΣΜΟΣ" image="https://static.wixstatic.com/media/335ee3_9c6d7b8f7e694e40b10bda0de7eee0f0~mv2.jpg/v1/fill/w_1920,h_600,al_c,q_80,enc_avif,quality_auto/LSD_4282.jpg" />
      <section style={{ padding: "80px 24px", maxWidth: 1100, margin: "0 auto" }}>
        <Reveal>
          <h2 className="gold-text" style={{ textAlign: "center", fontSize: "1.8rem", marginBottom: 30 }}>ΔΙΑΓΩΝΙΣΤΙΚΑ ΘΕΜΑΤΑ</h2>
        </Reveal>
        <Reveal delay={100}>
          <p style={{ color: "#bbb", fontSize: "0.95rem", lineHeight: 1.9, textAlign: "center", maxWidth: 860, margin: "0 auto 50px" }}>
            Ο μεγαλύτερος διαγωνισμός στην Ελλάδα όπου συμμετέχουν οι κορυφαίοι barbers της Ελλάδας με αναγνωρισιμότητα σε παγκόσμιο επίπεδο. Ο διαγωνισμός πληρεί ευρωπαϊκές προδιαγραφές και κριτές είναι ξένοι αναγνωρισμένοι εκπαιδευτές από όλη την Ευρώπη. Δηλώστε συμμετοχή στον διαγωνισμό και διεκδικήστε τον τίτλο του <strong style={{ color: "var(--color-gold)" }}>&quot;Best Barber of the Year 2026&quot;</strong> καθώς επίσης και πλούσια δώρα. Τα διαγωνιστικά θέματα είναι 4: &quot;Old School Haircuts&quot;, &quot;Free Style-Total Look&quot;, &quot;Fastest Low Fade&quot;, &quot;Modern Barbering&quot;. Μπορείτε να δηλώσετε συμμετοχή σε ένα ή περισσότερα θέματα. Για να διεκδικήσετε τον τίτλο θα πρέπει να πάρετε μέρος σε τουλάχιστον 3 διαγωνιστικά θέματα. Σε περίπτωση συμμετοχής και στα 4 θέματα, θα κρατηθεί το αποτέλεσμα από την υψηλότερη βαθμολογία. Παρακαλώ διαβάστε προσεκτικά παρακάτω όλες τις λεπτομέρειες.
          </p>
        </Reveal>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24 }}>
          {CATEGORIES.map((cat, i) => (
            <Reveal key={cat.href} delay={i * 150}>
              <Link href={cat.href} className="card-hover" style={{ display: "block", textDecoration: "none", borderRadius: 16, overflow: "hidden", border: "1px solid rgba(200,168,78,0.15)", background: "var(--color-charcoal)" }}>
                <div className="img-zoom" style={{ height: 300 }}>
                  <img src={cat.image} alt={cat.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
                <div style={{ padding: "20px 24px" }}>
                  <h3 style={{ color: "var(--color-gold)", fontSize: "1.1rem", marginBottom: 4 }}>{cat.title}</h3>
                  <p style={{ color: "#999", fontSize: "0.85rem", marginBottom: 8 }}>Χρόνος: {cat.time}</p>
                  <p style={{ color: "#bbb", fontSize: "0.85rem", lineHeight: 1.6 }}>{cat.desc}</p>
                  <span style={{ display: "inline-block", marginTop: 12, color: "var(--color-gold)", fontSize: "0.8rem", fontFamily: "var(--font-display)", borderBottom: "1px solid var(--color-gold)" }}>Περισσότερα →</span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div style={{ background: "var(--color-charcoal)", borderRadius: 16, padding: "40px 32px", border: "1px solid rgba(200,168,78,0.2)", marginTop: 60 }}>
            <h3 className="gold-text" style={{ fontSize: "1.2rem", marginBottom: 24, textAlign: "center" }}>Σημαντικές Σημειώσεις</h3>
            <ol style={{ paddingLeft: 20 }}>
              {NOTES.map((note, i) => (
                <li key={i} style={{ color: "#bbb", fontSize: "0.9rem", lineHeight: 1.8, marginBottom: 12 }}>{note}</li>
              ))}
            </ol>
            <p style={{ color: "#aaa", fontSize: "0.85rem", marginTop: 20, textAlign: "center" }}>
              Για περισσότερες πληροφορίες σχετικά με τους όρους του διαγωνισμού,{" "}
              <Link href="/competition/rules" style={{ color: "var(--color-gold)" }}>δείτε τους Όρους Συμμετοχής</Link>.
            </p>
          </div>
        </Reveal>

        <div style={{ marginTop: 40, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 }}>
          {[
            { label: "Μαθητικός Διαγωνισμός", href: "/competition/student" },
            { label: "Κόστος Συμμετοχής", href: "/competition/fees" },
            { label: "Όροι Συμμετοχής", href: "/competition/rules" },
          ].map((link) => (
            <Reveal key={link.href}>
              <Link href={link.href} style={{ display: "block", textDecoration: "none", textAlign: "center", padding: "20px", background: "rgba(200,168,78,0.08)", borderRadius: 12, border: "1px solid rgba(200,168,78,0.15)", color: "var(--color-gold)", fontFamily: "var(--font-display)", fontSize: "0.95rem", transition: "all 0.3s" }}>
                {link.label}
              </Link>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
